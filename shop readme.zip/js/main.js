// Theme toggle
const toggleThemeBtn = document.querySelectorAll('#toggleTheme');
toggleThemeBtn.forEach(btn => {
  btn.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    btn.textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
  });
});

// Cart Functions
function saveCart(cart) {
  localStorage.setItem('cart', JSON.stringify(cart));
}

function getCart() {
  return JSON.parse(localStorage.getItem('cart')) || [];
}
// 🧾 Update Cart Count (Top Navbar)
function updateCartCount() {
  const cart = getCart();
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartCount = document.getElementById('cartCount');
  if (cartCount) cartCount.textContent = count;
}

// Initialize count on load
updateCartCount();


