const checkoutItems = document.getElementById('checkoutItems');
const checkoutTotal = document.getElementById('checkoutTotal');
const checkoutForm = document.getElementById('checkoutForm');

function renderCheckout() {
  const cart = getCart();
  if(cart.length === 0) {
    checkoutItems.innerHTML = '<p>Your cart is empty.</p>';
    checkoutTotal.textContent = 0;
    return;
  }

  checkoutItems.innerHTML = cart.map(item => `
    <p>${item.title} x ${item.quantity} - $${(item.price*item.quantity).toFixed(2)}</p>
  `).join('');

  const total = cart.reduce((sum, item) => sum + item.price*item.quantity, 0);
  checkoutTotal.textContent = total.toFixed(2);
}

checkoutForm.addEventListener('submit', e => {
  e.preventDefault();
  alert('Order placed successfully!');
  localStorage.removeItem('cart');
  window.location.href = 'index.html';
});

renderCheckout();
