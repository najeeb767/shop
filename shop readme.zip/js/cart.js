const cartItems = document.getElementById('cartItems');
const cartTotal = document.getElementById('cartTotal');

function renderCart() {
  const cart = getCart();
  if(cart.length === 0) {
    cartItems.innerHTML = '<p>Your cart is empty.</p>';
    cartTotal.textContent = 0;
    return;
  }

  cartItems.innerHTML = cart.map(item => `
    <div class="d-flex align-items-center mb-3">
      <img src="${item.image}" alt="${item.title}" style="width:80px;height:80px;object-fit:contain;">
      <div class="ms-3 flex-grow-1">
        <h5>${item.title}</h5>
        <p>$${item.price}</p>
        <div>
          <button class="btn btn-sm btn-secondary" onclick="changeQty(${item.id},-1)">-</button>
          <span class="mx-2">${item.quantity}</span>
          <button class="btn btn-sm btn-secondary" onclick="changeQty(${item.id},1)">+</button>
          <button class="btn btn-sm btn-danger ms-2" onclick="removeItem(${item.id})">Delete</button>
        </div>
      </div>
    </div>
  `).join('');

  const total = cart.reduce((sum, item) => sum + item.price*item.quantity, 0);
  cartTotal.textContent = total.toFixed(2);
}

function changeQty(id, delta) {
  const cart = getCart();
  const item = cart.find(i => i.id === id);
  if(!item) return;
  item.quantity += delta;
  if(item.quantity <= 0) removeItem(id);
  saveCart(cart);
  renderCart();
}

function removeItem(id) {
  let cart = getCart();
  cart = cart.filter(i => i.id !== id);
  saveCart(cart);
  renderCart();
}

renderCart();
