const productsContainer = document.getElementById('productsContainer');
const priceRange = document.getElementById('priceRange');
const priceValue = document.getElementById('priceValue');
const searchInput = document.getElementById('searchInput');

let products = [];

async function fetchProducts() {
  const res = await fetch('https://fakestoreapi.com/products');
  const data = await res.json();
  // duplicate products to increase number
  products = [...data, ...data]; // now 40 products shown
  displayProducts(products);
}

// 💫 Animate product cards when they appear
document.addEventListener("DOMContentLoaded", () => {
  const products = document.querySelectorAll("#productsContainer .card");
  products.forEach((card, i) => {
    card.style.setProperty("--delay", `${i * 0.15}s`);
  });

  // Dynamic price display
  const range = document.getElementById("priceRange");
  const priceValue = document.getElementById("priceValue");

  if (range && priceValue) {
    range.addEventListener("input", () => {
      priceValue.textContent = `$${range.value}`;
    });
  }
});


function displayProducts(list) {
  productsContainer.innerHTML = list.map(p => `
    <div class="col-lg-3 col-md-4 col-sm-6 mb-4">

      <div class="card h-100">
        <img src="${p.image}" class="card-img-top p-3" alt="${p.title}" style="height:250px;object-fit:contain;">
        <div class="card-body d-flex flex-column">
          <h5 class="card-title">${p.title}</h5>
          <p class="card-text">$${p.price}</p>
          <button class="btn btn-primary mt-auto" onclick="addToCart(${p.id})">Add to Cart</button>
        </div>
      </div>
    </div>
  `).join('');
}

function addToCart(id) {
  const cart = getCart();
  const product = products.find(p => p.id === id);
  const existing = cart.find(item => item.id === id);
  if(existing) existing.quantity += 1;
  else cart.push({ ...product, quantity: 1 });
  saveCart(cart);
  saveCart(cart);
updateCartCount();
alert('Added to cart!');

  alert('Added to cart!');
}

// Price filter
priceRange.addEventListener('input', () => {
  const value = parseFloat(priceRange.value);
  priceValue.textContent = value;
  displayProducts(products.filter(p => p.price <= value));
});

// Search filter
searchInput.addEventListener('input', () => {
  const term = searchInput.value.toLowerCase();
  displayProducts(products.filter(p => p.title.toLowerCase().includes(term)));
});

fetchProducts();
